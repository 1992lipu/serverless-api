module.exports = {
  url: 'mongodb://localhost:27017/kontraktDB',
  mongoURI: 'mongodb://master:Hello123$@docdb-2019-08-22-04-04-05.cluster-clywdovbr7ty.us-east-1.docdb.amazonaws.com:27017/?ssl=true&ssl_ca_certs=rds-combined-ca-bundle.pem&replicaSet=rs0',
  mongoCloudUri: 'mongodb+srv://master:master123@cluster0-shrpg.mongodb.net/test?retryWrites=true&w=majority'
}
