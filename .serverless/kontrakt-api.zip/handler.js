module.exports.loginHandler = require('./handlers/loginHandler.js');

// module.exports.healthCheckHandler = (event, context, callback) => {
//     const response = {
//         statusCode: 200,
//         body: JSON.stringify({
//           message: 'DB Success',
//         }),
//       };
//       callback(null, response);
//       return;
//   };