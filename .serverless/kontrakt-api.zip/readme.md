# KontraktAPI
API code for Kontrakt App


set AWS_PROFILE=kontrakt
set AWS_REGION=us-east-1
set KONTRAKT_ENV=dev
set KONTRACT_API_DOMAIN=api.backend.dev.kontrakt.co
set VIRTUAL_PORT=3000
set CERT_ARN=arn:aws:acm:us-east-1:003318891738:certificate/cbdab353-77da-4922-aa98-bf3705dbb663